import { SignIn } from "@clerk/nextjs"

const Page = () => {
  return (
    <SignIn />
  )
}

export default Page